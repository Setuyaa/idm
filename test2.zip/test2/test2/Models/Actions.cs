﻿using System;
using System.ComponentModel.DataAnnotations;

namespace test2.Models
{
    public enum EActions
    {
        LoggedIn,
        LoggedOut
    }
    public class Actions
    {
        [Key]
        public int Id { get; set; }
        [Range(0, 2, ErrorMessage = "the range is incorrect")]
        public int IdAction { get; set; }
        [Required]
        public int UserID { get; set; }
        [Required]
        public DateTime CreatedDateTime { get; set; } = DateTime.Now.ToUniversalTime();
        public string Description { get; set; }
    }
}