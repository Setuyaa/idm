﻿using System;
using System.ComponentModel.DataAnnotations;

namespace test2.Models
{
    public class ServiceUser
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        [PasswordRequirements(ErrorMessage = "Password must contain at least 8 characters, one uppercase letter, one digit, and one special character")]
        public string Password { get; set; }
        //[RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*d)(?=.*[W_]).{8,}$", ErrorMessage = "Password must contain at least one lowercase letter, one uppercase letter, one digit, and one special character")]
        //[Required(AllowEmptyStrings = true)]
        //[StringLength(maximumLength: 100, MinimumLength = 0)]
        [PasswordRequirements(ErrorMessage = "Password must contain at least 8 characters, one uppercase letter, one digit, and one special character")]
        public string NewPassword { get; set; }
        public bool KeepInLog { get; set; }
    }
    public class PasswordRequirementsAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            string password = value as string;

            if (password == null)
            {
                return false;
            }
            if (password.Length < 8)
            {
                return false;
            }
            if (!password.Any(char.IsUpper))
            {
                return false;
            }
            if (!password.Any(char.IsDigit))
            {
                return false;
            }
            if (!password.Any(ch => !char.IsLetterOrDigit(ch)))
            {
                return false;
            }
            return true;
        }
    }

}

