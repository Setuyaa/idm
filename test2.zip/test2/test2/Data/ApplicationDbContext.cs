﻿
using System;
using Microsoft.EntityFrameworkCore;
using test2.Models;
namespace test2.Data
{
	public class ApplicationDbContext:DbContext
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
		{
		}
		public DbSet<Category> Categories { get; set; }
        public DbSet<ServiceUser> Admins { get; set; }
		public DbSet<Actions> Actions { get; set; }
    }

}

