﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace test2.Controllers
{
    public class RSAController : Controller
    {
        public static char[] characters = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
                                                'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
                                                'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd',
                                                'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
                                                'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x',
                                                'y', 'z', '1', '2', '3', '4', '5', '6', '7', '8',
                                                '9', '0', '!', '&', '#', '(', ')', '@', '$', '%',
                                                '^', '&', '*', '/', '<', '>', ',', '.', '?', '/',
                                                ';', ':', '{', '}', '[', ']', '=', '+', '-', '_',
                                                '~'};

        public List<string> RSA_Endoce(string s, long el, long n)
        {
            List<string> result = new List<string>();

            BigInteger bi;

            for (int i = 0; i < s.Length; i++)
            {
                int index = Array.IndexOf(characters, s[i]);

                bi = new BigInteger(index);
                bi = BigInteger.ModPow(bi, el, n);
                string bi_s = "";
                if (bi < 1000000000)
                    bi_s = bi_s.Insert(0, "0");
                bi_s = bi_s.Insert(bi_s.Length, bi.ToString());
                result.Add(bi_s);
            }

            return result;
        }
        public string RSA_Dedoce(string input, long d, long n)
        {
            string result = "";
            List<string> inputList = new List<string>();
            for (int i = 0; i < input.Length; i += 10)
            {
                if (i + 10 <= input.Length)
                    inputList.Add(input.Substring(i, 10).ToString());
                else
                    inputList.Add(input.Substring(i).ToString());
            }

            BigInteger bi;

            foreach (string item in inputList)
            {
                bi = new BigInteger(Convert.ToDouble(item));
                bi = BigInteger.ModPow(bi, d, n);

                long index = Convert.ToInt64(bi.ToString());

                result += characters[index].ToString();
            }
            return result;
        }
    }
}

