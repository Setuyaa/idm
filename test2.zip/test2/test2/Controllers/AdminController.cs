﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using test2.Data;
using test2.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace test2.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _db;
        public AdminController(ApplicationDbContext db)
        {
            _db = db;
        }
        // GET: /<controller>/
        public IActionResult AdminArea()
        {
            IEnumerable<ServiceUser> objAdmins = _db.Admins;
            return View(objAdmins);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public IActionResult Create(ServiceUser obj)
        {
            if (obj.Email != null && obj.Password != null)
            {
                obj.NewPassword = " ";
                _db.Admins.Add(obj);
                _db.SaveChanges();
                TempData["success"] = "User created successfully";
                return RedirectToAction("AdminArea");
            }
            return View(obj);
        }
        public IActionResult Edit(int? id)
        {
            if (id == 0 || id == null)
                return NotFound();
            var obj = _db.Admins.Find(id);
            if (obj == null)
                return NotFound();
            return View(obj);
        }
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public IActionResult Edit(ServiceUser obj)
        {
            if (obj.Email != null)
            {
                if (obj.NewPassword != null && obj.NewPassword != " ")
                {
                    obj.Password = obj.NewPassword;
                    obj.NewPassword = " ";
                    long e_ = 194080023; //zk1
                    long p = 80021;
                    long q = 80039;
                    long n = p * q;
                    RSAController rsa = new RSAController();
                    //endoce
                    List<string> result = new List<string>();
                    result = rsa.RSA_Endoce(obj.Password, e_, n);
                    string endoced = string.Join("", result);
                    obj.Password = endoced;
                }
                _db.Admins.Update(obj);
                _db.SaveChanges();
                TempData["success"] = "User updated successfully";
                return RedirectToAction("AdminArea");
            }
            return View(obj);
        }
        public IActionResult Delete(int? id)
        {
            if (id == 0 || id == null)
                return NotFound();
            var adminFromDb = _db.Admins.Find(id);
            if (adminFromDb == null)
                return NotFound();
            return View(adminFromDb);
        }
        [HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        public IActionResult DeletePOST(int? id)
        {
            var obj = _db.Admins.Find(id);
            if (obj == null)
                return NotFound();
            _db.Admins.Remove(obj);
            _db.SaveChanges();
            TempData["success"] = "User deleted successfully";
            return RedirectToAction("AdminArea");
        }
    }

}

