﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using test2.Models;
using test2.Data;
using System.Numerics;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace test2.Controllers
{

    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _db;

    
        public AccountController(ApplicationDbContext db)
        {
            _db = db;
        }
        [HttpGet]
        public IActionResult Login()
        {
            ClaimsPrincipal claims = HttpContext.User;
            if (claims.Identity.IsAuthenticated) {
                return RedirectToAction("Index", "Home");
            }
            // Вывод страницы авторизации
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(ServiceUser user)
        {
            var adminFromDb = _db.Admins.FirstOrDefault(p => p.Email==user.Email);
            long p = 80021;
            long q = 80039;
            long d = 6404640727; //ok1
            long e_ = 194080023; //zk1
            long n = p * q;
            long m = (p - 1) * (q - 1);
            RSAController rsa = new RSAController();
            //endoce
            List<string> result = new List<string>();

            result = rsa.RSA_Endoce(user.Password, e_, n);
            string endoced = string.Join("", result);
            if (adminFromDb != null && endoced == adminFromDb.Password)
            {
                List<Claim> claims = new List<Claim>() {
                    new Claim(ClaimTypes.NameIdentifier, user.Email),
                    new Claim("OtherProperties", "Example Role"),
                };
                ClaimsIdentity claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                AuthenticationProperties properties = new AuthenticationProperties()
                {
                    AllowRefresh = true,
                    IsPersistent = user.KeepInLog
                };
                Actions action = new Actions();
                action.Description = "User logged in system";
                action.IdAction = (int)EActions.LoggedIn;
                action.UserID = user.Id;
                _db.Actions.Add(action);
                _db.SaveChanges();

                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), properties);
                return RedirectToAction("Index", "Home");
            }
            ViewData["ValidateMessage"] = "User not found";
            return View();
            // Проверка учетных данных пользователя и, если они верны, аутентификация
        }

        public IActionResult AccessDenied()
        {
            return RedirectToAction("Error", "Home");
        }
    }
}

